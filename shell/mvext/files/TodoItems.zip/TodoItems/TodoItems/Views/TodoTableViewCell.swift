//
//  TodoTableViewCell.swift
//  TodoItems
//
//  Created by Derrick Park on 2018-10-15.
//  Copyright © 2018 Derrick Park. All rights reserved.
//

import UIKit

class TodoTableViewCell: UITableViewCell {
  @IBOutlet weak var checkmark: UILabel!
  @IBOutlet weak var todoLabel: UILabel!
}
